describe('Defaults test', () => {
  it.skip('plugin should be defined', () => {
    expect(true).toBeTruthy();
  });
});
