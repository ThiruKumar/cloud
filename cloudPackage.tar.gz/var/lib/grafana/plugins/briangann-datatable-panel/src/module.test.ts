describe('module test', () => {
  it.skip('plugin should be defined', () => {
    expect(true).toBeTruthy();
  });
});
