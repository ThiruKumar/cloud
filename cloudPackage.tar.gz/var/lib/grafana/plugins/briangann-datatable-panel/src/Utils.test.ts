describe('Utils test', () => {
  it.skip('GetColorForValue', () => {
    expect(true).toBeTruthy();
  });
});
