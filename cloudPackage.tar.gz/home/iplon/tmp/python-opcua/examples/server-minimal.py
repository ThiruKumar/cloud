import sys
sys.path.insert(0, "..")
import time
import json
from datetime import datetime

from opcua import ua, Server
from opcua.common.ua_utils import get_nodes_of_namespace

from influxdb import InfluxDBClient


# setup our server
server = Server()
# Opening JSON file 

f = open('/home/iplon/tmp/python-opcua/examples/data.json',)
#f = open('data.json',)

# returns JSON object as a dictionary 
data = json.load(f) 

# Closing file 
f.close() 
    
# setup our own namespace, not really necessary but should as spec
uri = str(data['address_space'])
idx = server.register_namespace(uri)

# get Objects node, this is where we should put our nodes
objects = server.get_objects_node()

client   = InfluxDBClient(data['hostname'], data['port'], data['db_username'], data['db_password'], data['source_db'])



def frame_influx_query(k):
    q_str = ""
    for it_count,query_filter in enumerate(k):
        if(it_count < len(query_filter)):
            q_str = q_str + '"'+query_filter['key']+'" = \''+query_filter['value']+'\' AND '
        else:
            q_str = q_str + '"'+query_filter['key']+'" = \''+query_filter['value']+'\''
    return q_str

def load_config():
    for i in data['cumulative_nodes']:
                    # populating our address space

                        myobj = objects.add_object("ns="+str(idx)+"; i="+str(i['requested_nodeid']), str(i['browsename']))
                        #print("#######\n")
                        #print(myobj)
                        #print(server.get_objects_node().get_children()[1].get_browse_name())
                        #print("#######\n") 
                        for j in i['fields']:
                            #myvar = myobj.add_variable(idx, str(j['requested_nodeid']), 6.7)
                            myvar = myobj.add_variable("ns="+str(idx)+"; i="+str(j['requested_nodeid']), str(j['browsename']), 0)
                            #print("#######\n")
                            #print(myvar)
                            #print(idx)
                            #print(myvar.get_browse_name())
                            #print("#######\n")
                            #print(server.get_namespace_index(uri))
                            #print(get_nodes_of_namespace())


def update_data():
    for i in data['cumulative_nodes']:
                    # populating our address space
                        #namespaces = [idx]
                        
                        myobj = server.get_node(i['requested_nodeid'])
                        for it_count,j in enumerate(i['fields']):
                            #myvar = server.get_node(j['requested_nodeid'])
                            #print(server.get_node(ua.NodeId.from_string('ns=%d;i=2' % idx)).get_value())
                            #server.get_node(ua.NodeId.from_string('ns='+str(idx)+';i='+str(j['requested_nodeid']))).set_value(9.8)
                            #print(it_count+1)
                            #print(server.get_node(ua.NodeId.from_string('ns='+str(idx)+';i='+str(j['requested_nodeid']))).get_value())
                            #print(server.set_attribute_value(myvar,7.5656))
                            #print(server.get_namespace_index(uri))
                            #print(server.get_node(ua.ObjectIds.SolarData))
                            #for n in get_nodes_of_namespace(server,namespaces):
                                #print(server.get_node("ns=2;i=3").get_value())
                                #print(n.get_node_class())
                                #if(n.get_node_class() == ua.NodeClass.Variable):
                                    #print(n)
                                #print(objects.get_children()[1].get_children()[0].get_attributes())
                            #print(server.get_node(ua.NodeId.from_string('ns='+str(idx)+';i='+str(j['requested_nodeid']))).get_browse_name())
                            #print(myvar.get_value())
                            my_q_str = frame_influx_query(j['uniqueFilter'])
                            #print('select * from v where '+my_q_str+' AND time > now() - 60m');
                            result   = client.query('select * from v where '+my_q_str+' AND time > now() - 15m',{},{},'s')
                            inpoints = list(result.get_points(measurement='v'))
                            #result   = client.query('select * from scaback_csv where '+my_q_str+' AND time > now() - 1440m')
                            #inpoints = list(result.get_points(measurement='scaback_csv'))
                            if inpoints:
                                eg = inpoints[0]['value']
                                #server.get_node(ua.NodeId.from_string('ns='+str(idx)+';i=100000')).set_value(inpoints[0]['time'])
                                server.get_node(ua.NodeId.from_string('ns='+str(idx)+';i='+str(j['requested_nodeid']))).set_value(eg)
                                datavalue = ua.DataValue(inpoints[0]['value'])
                                #datavalue = ua.DataValue()
                                #print(inpoints[0]['time'])
                                #print(datetime.utcnow())
                                datavalue.SourceTimestamp = datetime.fromtimestamp(inpoints[0]['time'])
                                server.get_node(ua.NodeId.from_string('ns='+str(idx)+';i='+str(j['requested_nodeid']))).set_attribute(ua.AttributeIds.Value, datavalue)
                                #print(server.get_node(ua.NodeId.from_string('ns='+str(idx)+';i='+str(j['requested_nodeid']))).get_value())






if __name__ == "__main__":

    
    server.set_endpoint("opc.tcp://0.0.0.0:4840/iSolar/scaback_csv/")


            
    # if inpoints:
    #     eg = inpoints[0]['value']
    #     count += 0.1
    #     myvar.set_value(eg)                

    print("OPC UA Server Started !!!")
    # starting!
    server.start()
    load_config()
    try:
                count = 0
                while True:
                    time.sleep(60)
                    count += 0.1
                    update_data()
                    
    finally:
                #close connection, remove subcsriptions, etc
                server.stop()

