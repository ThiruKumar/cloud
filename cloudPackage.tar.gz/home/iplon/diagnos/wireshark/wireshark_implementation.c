#include<stdio.h>
#include<time.h>
int main()
{
	int i;
	char filename1[200];
	char filename2[200];
	char filename3[200];
	for(i=0;i<12;i++)    // 12 file generating in one day
	{
		struct tm *timenow;   //timestamp structure 		
		time_t now1 = time(NULL);    //timestamp datapoints
		sprintf(filename1, "/home/iplon/diagnos/wireshark/pcap_files/wireshark_%d.pcap", (int)now1);  //pcap file creation path define
		sprintf(filename2, "timeout 3600 tcpdump -i any -w %s", filename1);     //tcpdump cmd running for 1 hours
		system(filename2);   //system function is used for executing cmd 
	}
	struct tm *timenow;   //timestamp structure
	time_t now1 = time(NULL);   //timestamp datapoints
	sprintf(filename3, "tar -cjvf /home/iplon/diagnos/wireshark/tar_files/wireshark_%d.tar.gz /home/iplon/diagnos/wireshark/pcap_files/", (int)now1);  //tar file creation path define
	system(filename3);  //tar cmd execution in system function
	system("rm /home/iplon/diagnos/wireshark/pcap_files/*pcap");  //remove the pcap file which is generated in tcpdump
	system("find /home/iplon/diagnos/wireshark/tar_files/ -mtime +6 -type f -delete");  //After the 1 day delete the old files
}

