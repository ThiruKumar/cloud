#!/bin/bash
SOURCE_FILE=("/var/log/iplon/*.log" "/mnt/jffs2/log/y.log")
DEST_FILE=("/var/log/iGate_log/3097" "/var/log/iGate_log/3097/info_log")
HOSTS=("192.168.30.97" )
USERNAMES=("iplon" )
PASSWORDS=("arm9Solar" )
for i in ${!HOSTS[*]} ; do
    if [ "${HOSTS[i]}" == "192.168.30.97" ]; then
        for j in ${!SOURCE_FILE[*]} ; do
           if [ "${SOURCE_FILE[j]}" == "/var/log/iplon/*.log" ]; then
               sshpass -p ${PASSWORDS[i]} scp "${USERNAMES[i]}@${HOSTS[i]}:${SOURCE_FILE[j]}" ${DEST_FILE[0]}
           else    
               sshpass -p ${PASSWORDS[i]} scp "${USERNAMES[i]}@${HOSTS[i]}:${SOURCE_FILE[j]}" ${DEST_FILE[1]}
	   fi
        done
    fi
done

