#!/bin/bash
service1=scaback
service2=scabackFast
service3=grafana-server
service4=influxdb
service5=mysql
service6=telegraf

now=$(date +%s) 
echo "#id,value,fmt,ts,blockname,dev,chn" > /var/www/iSolar/fetchDDT/csv/service_alarm.csv

if (( $(ps -ef | grep -v grep | grep $service1 | wc -l) == 4 ))
then
echo "1,1,1,$now,PRI_SER,IO,SCABACK_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
service $service1 restart
else
echo "1,0,1,$now,PRI_SER,IO,SCABACK_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
fi

if (( $(ps -ef | grep -v grep | grep $service2 | wc -l) == 0 ))
then
echo "2,1,1,$now,PRI_SER,IO,SCABACKFAST_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
service $service2 restart
else
echo "2,0,1,$now,PRI_SER,IO,SCABACKFAST_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
fi

if (( $(ps -ef | grep -v grep | grep $service3 | wc -l) == 0 ))
then
echo "3,1,1,$now,PRI_SER,IO,GRAFANA_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
service $service3 restart
else
echo "3,0,1,$now,PRI_SER,IO,GRAFANA_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
fi

if (( $(ps -ef | grep -v grep | grep $service4 | wc -l) == 0 ))
then
echo "4,1,1,$now,PRI_SER,IO,INFLUXDB_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
service $service4 restart
else
echo "4,0,1,$now,PRI_SER,IO,INFLUXDB_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
fi

if (( $(ps -ef | grep -v grep | grep $service5 | wc -l) == 0 ))
then
echo "5,1,1,$now,PRI_SER,IO,MYSQL_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
service $service5 restart
else
echo "5,0,1,$now,PRI_SER,IO,MYSQL_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
fi

if (( $(ps -ef | grep -v grep | grep $service6 | wc -l) == 0 ))
then
echo "6,1,1,$now,PRI_SER,IO,TELEGRAF_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
service $service6 restart
else
echo "6,0,1,$now,PRI_SER,IO,TELEGRAF_RESTART" >> /var/www/iSolar/fetchDDT/csv/service_alarm.csv
fi

