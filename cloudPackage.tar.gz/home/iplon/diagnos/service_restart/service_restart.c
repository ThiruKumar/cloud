#include<stdio.h>
#include<time.h>
#include <stdlib.h>
int main()
{

        char dest_file[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
        FILE *dest_file_open = fopen(dest_file,"w+");
        fprintf(dest_file_open,"%s\n","#id,value,fmt,ts,blockname,dev,chn");
        fclose(dest_file_open);

//////////////////////////////////     scaback service Restart start ////////////////////////////////
        char source_file1[40] = "/var/run/scaback.pid";
        FILE *source_file1_open = fopen(source_file1,"r");
        if(source_file1_open==0)
        {
                struct tm *timenow;
                time_t now = time(NULL);
                char dest_file1[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
                FILE *dest_file1_open = fopen(dest_file1,"a");
                fprintf(dest_file1_open,"%d,%d,%d,%d,%s,%s,%s\n",1,1,1,(int)now,"PRI_SER","IO","SCABACK_RESTART");
                printf("scaback service restart at ----------------------------------------------- %d \n",(int)now);
                system("service scaback start");
                fclose(dest_file1_open);
        }
        else if(source_file1_open!=0)
        {
                struct tm *timenow;
                time_t now = time(NULL);
                char dest_file1[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
                FILE *dest_file1_open = fopen(dest_file1,"a");
                fprintf(dest_file1_open,"%d,%d,%d,%d,%s,%s,%s\n",1,0,1,(int)now,"PRI_SER","IO","SCABACK_RESTART");
                fclose(dest_file1_open);
        }
//////////////////////////////////     scaback service Restart start ////////////////////////////////

//////////////////////////////////     scabackFast service Restart start ////////////////////////////////
		char source_file2[40] = "/var/run/scabackFast.pid";
		FILE *source_file2_open = fopen(source_file2,"r");
		if(source_file2_open==0)
		{
			struct tm *timenow;  
			time_t now = time(NULL);
			char dest_file2[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
    	   		FILE *dest_file2_open = fopen(dest_file2,"a");
    	   		fprintf(dest_file2_open,"%d,%d,%d,%d,%s,%s,%s\n",2,1,1,(int)now,"PRI_SER","IO","SCABACKFAST_RESTART");
			printf("scabackFast service restart at ------------------------------------------- %d \n",(int)now);
			system("service scabackFast start");
			fclose(dest_file2_open);		
		}
		else if(source_file2_open!=0)
		{
			struct tm *timenow;  
			time_t now = time(NULL);
			char dest_file2[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
    	    		FILE *dest_file2_open = fopen(dest_file2,"a");
    	   		fprintf(dest_file2_open,"%d,%d,%d,%d,%s,%s,%s\n",2,0,1,(int)now,"PRI_SER","IO","SCABACKFAST_RESTART");
    	   		fclose(dest_file2_open);	
		}
////////////////////////////////// scaback service Restart stop ////////////////////////////////

//////////////////////////////////     influxdb.service Restart start ////////////////////////////////
		char source_file3[40] = "/var/run/influxdb/influxd.pid";
		FILE *source_file3_open = fopen(source_file3,"r");
		if(source_file3_open==0)
		{
			struct tm *timenow;  
			time_t now = time(NULL);
			char dest_file3[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
			FILE *dest_file3_open = fopen(dest_file3,"a");
    	 		fprintf(dest_file3_open,"%d,%d,%d,%d,%s,%s,%s\n",3,1,1,(int)now,"PRI_SER","IO","INFLUXDB_RESTART");
			printf("influxdb service restart at ---------------------------------------------- %d \n",(int)now);
			system("service influxdb start");
			fclose(dest_file3_open);	
		}
		else if(source_file3_open!=0)
		{
			struct tm *timenow;  
			time_t now = time(NULL);
			char dest_file3[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
			FILE *dest_file3_open = fopen(dest_file3,"a");
    			fprintf(dest_file3_open,"%d,%d,%d,%d,%s,%s,%s\n",3,0,1,(int)now,"PRI_SER","IO","INFLUXDB_RESTART");
			fclose(dest_file3_open);
		}
////////////////////////////////// influxdb.service Restart stop ////////////////////////////////

////////////////////////////////// grafana-server.service Restart start ////////////////////////////////
		char source_file4[40] = "/var/run/grafana-server.pid";
		FILE *source_file4_open = fopen(source_file4,"r");
		if(source_file4_open==0)
		{
			struct tm *timenow;  
			time_t now = time(NULL);
			char dest_file4[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
			FILE *dest_file4_open = fopen(dest_file4,"a");
   		 	fprintf(dest_file4_open,"%d,%d,%d,%d,%s,%s,%s\n",4,1,1,(int)now,"PRI_SER","IO","GRAFANA_RESTART");
			printf("grafana-server service restart at ---------------------------------------- %d \n",(int)now);
			system("service grafana-server start");
			fclose(dest_file4_open);
		}
		else if(source_file4_open!=0)
		{
			struct tm *timenow;  
			time_t now = time(NULL);
			char dest_file4[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
			FILE *dest_file4_open = fopen(dest_file4,"a");
    			fprintf(dest_file4_open,"%d,%d,%d,%d,%s,%s,%s\n",4,0,1,(int)now,"PRI_SER","IO","GRAFANA_RESTART");
			fclose(dest_file4_open);	
		}
////////////////////////////////// grafana-server.service Restart stop ////////////////////////////////

////////////////////////////////// mysql.service Restart start ////////////////////////////////
		char source_file5[40] = "/var/run/mysqld/mysqld.pid";
		FILE *source_file5_open = fopen(source_file5,"r");
		if(source_file5_open==0)
		{
			struct tm *timenow;  
			time_t now = time(NULL);
			char dest_file5[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
			FILE *dest_file5_open = fopen(dest_file5,"a");
    			fprintf(dest_file5_open,"%d,%d,%d,%d,%s,%s,%s\n",5,1,1,(int)now,"PRI_SER","IO","MYSQL_RESTART");
			printf("mysql service restart at ------------------------------------------------- %d \n",(int)now);
			system("service mysql start");
			fclose(dest_file5_open);	
		}
		else if(source_file5_open!=0)
		{
			struct tm *timenow;  
			time_t now = time(NULL);
			char dest_file5[50] = "/var/www/iSolar/fetchDDT/csv/service_alarm.csv";
			FILE *dest_file5_open = fopen(dest_file5,"a");
 	   		fprintf(dest_file5_open,"%d,%d,%d,%d,%s,%s,%s\n",5,0,1,(int)now,"PRI_SER","IO","MYSQL_RESTART");
			fclose(dest_file5_open);	
		}
////////////////////////////////// mysql.service Restart stop ////////////////////////////////
fcloseall();
}

