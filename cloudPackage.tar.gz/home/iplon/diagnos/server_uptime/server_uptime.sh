#!/bin/bash

{ uptime -s ;uptime ;} > uptime.log 

 sed 'N;s/\n/ /' uptime.log | tee -a /var/log/server_uptime.log


