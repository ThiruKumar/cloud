#!/bin/bash

sleep 3;
cd /home/iplon/diagnos/prometheus/prometheus-2.9.2.linux-amd64/
./prometheus
