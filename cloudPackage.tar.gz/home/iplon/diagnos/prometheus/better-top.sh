#!/bin/bash

while true; do
   /home/iplon/diagnos/prometheus/better-top-CPU 
   /home/iplon/diagnos/prometheus/better-top-RAM
   sleep 15;
done
