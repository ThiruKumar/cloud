#!/bin/bash

cd /home/iplon/diagnos/prometheus/pushgateway-0.8.0.linux-amd64/
./pushgateway
